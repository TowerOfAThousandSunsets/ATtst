Name: Nanachi (《Made In Abyss》)
CV: 井澤詩織 (Shiori Izawa)
原音設定: 4LTetFA

//Just read what's in 【】
//【】の中を読めばいい

带ん的音请拆成类似【 san -> sa_ + _an 】的形式, ゃ、ゅ、ょ拆成【 kyo -> ki_ + _yo 】形式
pa行音不全请用ba行代替【 pa/pi/po/pe -> ba/bi/bo/be】
^^^^^^
Readme